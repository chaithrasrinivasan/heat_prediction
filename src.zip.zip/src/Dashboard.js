import WeatherCards from "./WeatherCards";
import Chatbot from "./Chatbot";

function Dashboard() {
  // Backend will replace this later
  const data = null;

  return (
    <div style={{ display: "flex", width: "100%" }}>

      {/* LEFT SIDE */}
      <div className="dashboard">

        {/* Weather Cards */}
        <WeatherCards data={data} />

        {/* Areas in Chennai */}
        <div className="card">
          <h3>Areas in Chennai</h3>
          <p>📍 Anna Nagar</p>
          <p>📍 T Nagar</p>
          <p>📍 Velachery</p>
          <p>📍 Adyar</p>
        </div>

        {/* Heat Map Section */}
        <div className="card" style={{ marginTop: "20px" }}>
          <h3>Chennai - Heat Zones</h3>
          <p style={{ color: "#aaa" }}>
            Map will be displayed after backend integration
          </p>
        </div>

        {/* Climate Graph */}
        <div className="card" style={{ marginTop: "20px" }}>
          <h3>Climate Trend (Next 7 Days)</h3>
          <p style={{ color: "#aaa" }}>
            Graph will be displayed after data integration
          </p>
        </div>

      </div>

      {/* RIGHT PANEL */}
      <div className="right-panel">

        {/* Area Dashboard */}
        <div className="card">
          <h3>Area Dashboard</h3>
          <p style={{ color: "#aaa" }}>Today's Data: --</p>
          <p style={{ color: "#aaa" }}>Tomorrow's Data: --</p>
          <p style={{ color: "#aaa" }}>Heat Risk: --</p>
        </div>

        {/* Solutions */}
        <div className="card" style={{ marginTop: "15px" }}>
          <h3>Solutions</h3>
          <p style={{ color: "#aaa" }}>
            Solutions will be shown based on prediction
          </p>
        </div>

        {/* Chatbot */}
        <Chatbot />

      </div>

    </div>
  );
}

export default Dashboard;