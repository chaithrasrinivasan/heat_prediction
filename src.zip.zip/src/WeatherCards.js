function WeatherCards({ data }) {
  return (
    <div className="cards">
      <div className="card">
        <h4>Current Temperature</h4>
        <h2 className="temp">
          {data?.temp ? `${data.temp}°C` : <span className="loading">Loading...</span>}
        </h2>
      </div>

      <div className="card">
        <h4>Humidity</h4>
        <h2 className="humidity">
          {data?.humidity ? `${data.humidity}%` : <span className="loading">Loading...</span>}
        </h2>
      </div>

      <div className="card">
        <h4>Wind Speed</h4>
        <h2 className="wind">
          {data?.wind ? `${data.wind} km/h` : <span className="loading">Loading...</span>}
        </h2>
      </div>

      <div className="card">
        <h4>Heat Risk</h4>
        <h2 className="risk">
          {data?.risk ? data.risk : <span className="loading">Loading...</span>}
        </h2>
      </div>
    </div>
  );
}
const data = {
  temp: null,
  humidity: null,
  wind: null,
  risk: null
};
export default WeatherCards;